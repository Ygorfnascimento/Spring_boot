package com.mercadolivro.controller.request

data class PostCustomerRequest(
    var name: String,
    var email: String
)