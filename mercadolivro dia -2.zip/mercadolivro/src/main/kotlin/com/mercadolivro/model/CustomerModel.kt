package com.mercadolivro.model

data class CustomerModel (
    var id: String,
    var name: String,
    var email: String
)