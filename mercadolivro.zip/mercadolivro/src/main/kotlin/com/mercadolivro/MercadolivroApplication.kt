package com.mercadolivro

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class MercadolivroApplication

fun main(args: Array<String>) {
	runApplication<MercadolivroApplication>(*args)
}
